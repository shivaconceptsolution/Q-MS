from django.contrib import admin
from .models import Reg
admin.site.register(Reg)
