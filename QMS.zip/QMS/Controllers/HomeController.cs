﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using QMS.Models;
namespace QMS.Controllers
{
    public class HomeController : Controller
    {
        Database1Entities db = new Database1Entities();
        //
        // GET: /Home/

        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]

        public ActionResult Index(Registration r)
        {
            var s = (from c in db.Registrations where c.userid == r.userid && c.password == r.password select c).FirstOrDefault();
            if (s != null)
            {
                TempData["mgrid"] = r.userid;
                TempData["role"] = s.role;
                TempData.Keep();
                return RedirectToAction("Index", "Dashboard");
            }
            else
            {
                ViewBag.data = "Invalid Userid and Password";
            }

            return View();
        }


        public ActionResult About()
        {
            return View();
        }
        public ActionResult Services()
        {
            return View();
        }
        public ActionResult Contact()
        {
            return View();
        }
        void viewfeedto()
        {
            List<SelectListItem> fd = new List<SelectListItem>();
            var s = (from c in db.Registrations select new { feedto = c.role }).ToList();

            for (int i = 0; i < s.Count(); i++)
            {
                fd.Add(new SelectListItem() { Text = s.ElementAt(i).feedto.ToString(), Value = s.ElementAt(i).feedto.ToString() });
            }
            ViewBag.feeds = fd;
        }
        public ActionResult Feedback()
        {
            viewfeedto();
            return View();
        }
        [HttpPost] 
        public ActionResult Feedback(Feedback o)
        {
            o.FeedTo = Request["feeds"];
            db.Feedbacks.Add(o);
            db.SaveChanges();
            viewfeedto();
            ViewBag.data = "Data Inserted Successfully";
            return View();
        }

        public ActionResult SignUp()
        {

            return View();
        }
       [HttpPost]
        public ActionResult SignUp(Registration r)
        {
            r.role = "Manager";
            db.Registrations.Add(r);
            db.SaveChanges();
            ViewBag.data = "Data Inserted Successfully";
            return View();
        }
    }
}
