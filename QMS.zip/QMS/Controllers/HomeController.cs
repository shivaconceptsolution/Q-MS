﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using QMS.Models;
namespace QMS.Controllers
{
    public class HomeController : Controller
    {
        Database1Entities db = new Database1Entities();
        //
        // GET: /Home/

        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]

        public ActionResult Index(Registration r)
        {
            var s = (from c in db.Registrations where c.userid == r.userid && c.password == r.password select c).FirstOrDefault();
            if (s != null)
            {
                TempData["mgrid"] = r.userid;
                TempData.Keep();
                return RedirectToAction("Index", "Dashboard");
            }
            else
            {
                ViewBag.data = "Invalid Userid and Password";
            }

            return View();
        }


        public ActionResult About()
        {
            return View();
        }
        public ActionResult Services()
        {
            return View();
        }
        public ActionResult Contact()
        {
            return View();
        }
        public ActionResult Feedback()
        {

            return View();
        }
        [HttpPost] 
        public ActionResult Feedback(Feedback o)
        {
            db.Feedbacks.Add(o);
            db.SaveChanges();
            ViewBag.data = "Data Inserted Successfully";
            return View();
        }

        public ActionResult SignUp()
        {

            return View();
        }
       [HttpPost]
        public ActionResult SignUp(Registration r)
        {
            r.role = "Manager";
            db.Registrations.Add(r);
            db.SaveChanges();
            ViewBag.data = "Data Inserted Successfully";
            return View();
        }
    }
}
