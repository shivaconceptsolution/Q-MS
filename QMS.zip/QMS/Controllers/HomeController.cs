﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using QMS.Models;
namespace QMS.Controllers
{
    public class HomeController : Controller
    {
        Database1Entities db = new Database1Entities();
        //
        // GET: /Home/

        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]

        public ActionResult Index(Registration r)
        {
            var s = (from c in db.Registrations where c.userid == r.userid && c.password == r.password select c).FirstOrDefault();
            if (s != null)
            {
                TempData["mgrid"] = r.userid;
                TempData["role"] = s.role;
                TempData.Keep();
                if (s.role == "Customer")
                {
                    return RedirectToAction("Index", "Customer");
                }
                else
                {
                    return RedirectToAction("Index", "Dashboard");
                    
                }
            }
            else
            {
                ViewBag.data = "Invalid Userid and Password";
            }

            return View();
        }


        public ActionResult About()
        {
            return View();
        }
        public ActionResult Services()
        {
            return View();
        }
        public ActionResult Contact()
        {
            return View();
        }
        void viewfeedto()
        {
            List<SelectListItem> fd = new List<SelectListItem>();
            var s = (from c in db.Registrations where c.role != "Customer" select new { feedto = c.role }).ToList();

            for (int i = 0; i < s.Count(); i++)
            {
                fd.Add(new SelectListItem() { Text = s.ElementAt(i).feedto.ToString(), Value = s.ElementAt(i).feedto.ToString() });
            }
            ViewBag.feeds = fd;
        }
        void viewfeedtonew()
        {
            List<SelectListItem> fd = new List<SelectListItem>();
            var s = (from c in db.Registrations  select new { feedto = c.role }).ToList();

            for (int i = 0; i < s.Count(); i++)
            {
                fd.Add(new SelectListItem() { Text = s.ElementAt(i).feedto.ToString(), Value = s.ElementAt(i).feedto.ToString() });
            }
            ViewBag.feeds = fd;
        }
       
        public ActionResult SignUp()
        {
            viewfeedtonew();
            return View();
        }
       [HttpPost]
        public ActionResult SignUp(Registration r)
        {
            r.role = Request["role"];
            db.Registrations.Add(r);
            db.SaveChanges();
            ViewBag.data = "Data Inserted Successfully";
            return View();
        }
    }
}
