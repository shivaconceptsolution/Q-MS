﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using QMS.Models;
using System.Data;
namespace QMS.Controllers
{
    public class DashboardController : Controller
    {
        //
        // GET: /Dashboard/
        String urole="";
        Database1Entities db = new Database1Entities();
        public ActionResult Index()
        {
           // var s = from c in db.Registrations select c;
            String uid = TempData["mgrid"].ToString();
            urole = TempData["role"].ToString();
            TempData.Keep();
            var s = from c in db.Registrations where c.userid.Equals(uid) select c;
           // return View(s.ToList());
             return View(s.ToList());
        }

        public ActionResult Edit(String id)
        {
         //   var s = from c in db.Registrations where c.userid == id select c;
            var s = db.Registrations.Find(id);
            return View(s);
        }
        [HttpPost]
        public ActionResult Edit(Registration r)
        {
            db.Entry(r).State = EntityState.Modified;   // ref is the reference of Model Class Object
            db.SaveChanges();

            return RedirectToAction("Index");
        }

        public ActionResult Details(String id)
        {
            var s = db.Registrations.Find(id);
            return View(s);
        }
        public ActionResult Delete(String id)
        {
            //   var s = from c in db.Registrations where c.userid == id select c;
            var s = db.Registrations.Find(id);
            return View(s);
        }
        [HttpPost]
        public ActionResult DeleteConfirmed(String userid)
        {
            var s= db.Registrations.Find(userid);
            db.Registrations.Remove(s);   //ref is the reference of Model Class Object
            db.SaveChanges();

            return RedirectToAction("Index");
        }

        public ActionResult ViewComplain()
        {
            string srole = TempData["role"].ToString();
            TempData.Keep();
            var s = from c in db.Feedbacks where c.FeedTo.Equals(srole) select c;
            return View(s.ToList());
        }
        public ActionResult ReplyTo(int id)
        {
            var s = db.Feedbacks.Find(id);
            TempData["FeedId"] = id;
            TempData["MgrId"] = TempData["mgrid"].ToString();
            TempData["CustName"] = s.CustomerName;
            TempData.Keep();
            return View();
        }

        [HttpPost]
        public ActionResult ReplyTo(Reply obj)
        {

           obj.FeedID = Convert.ToInt32(TempData["FeedId"].ToString());
           obj.ReplyBy=   TempData["mgrid"].ToString();
           obj.ReplyTo = TempData["CustName"].ToString();
           obj.ReplyMessage = obj.ReplyMessage;
           TempData.Keep();
           db.Replies.Add(obj);
           db.SaveChanges();
            return View();
        }
        public ActionResult Logout()
        {
            TempData.Remove("mgrid");
            TempData.Remove("role");
            return RedirectToAction("Index","Home");
        }
    }
}
